/* eslint-disable handle-callback-err */
const errorHandle = (err) => {
  // console.log('TCL: errorHandle -> err', err)
}

export default errorHandle
