<template>
  <div class="flex fly-panel fly-panel-user" pad20>正在开发中...</div>
</template>

<script>
export default {
  name: 'user-others'
}
</script>

<style lang="scss" scoped>
.flex {
  display: flex;
  font-size: 18px;
  color: #333;
  align-items: center;
  justify-content: center;
}
</style>
