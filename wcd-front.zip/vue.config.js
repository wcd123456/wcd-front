module.exports = {
  devServer: {
    // mock server
    // proxy: 'http://localhost:36742'
  }
}
